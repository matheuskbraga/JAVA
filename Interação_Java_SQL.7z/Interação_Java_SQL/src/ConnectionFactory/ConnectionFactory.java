
package ConnectionFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
    private Connection con;
    private final String url = "jdbc:mysql://localhost:3306/aula03_agendamento";
    //private final String driver = "com.mysql.cj.jdbc.Driver";
    private final String user = "root";
    private final String password = "laboratorio";
   
    //metodo de conexão
    public Connection getConnection(){
        Connection con = null;
        try{
            //Class.forName(driver); //verificação para ver se o driver esta de acordo
            con = DriverManager.getConnection(url, user, password);
            System.out.println("CONECTADO");
            return con;
        }catch(SQLException e){
            System.out.println("Erro ao conectar" + e);
            return null;
        }
    } 
}
