
package Vew;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;


public class ListarFuncionarios extends javax.swing.JFrame {

    
    public ListarFuncionarios() {
        initComponents();
        alterarColunas();      
    }

    public JButton getjBListar() {
        return jBListar;
    }

    public JButton getAlterar() {
        return Alterar;
    }

    public JButton getDeletar() {
        return Deletar;
    }

    public JButton getListar() {
        return jBListar;
    }

    public JButton getNew() {
        return New;
    }

    public JScrollPane getjScrollPane2() {
        return jScrollPane2;
    }

    public JTable getjTable2() {
        return jTable2;
    }
    
    public void alterarColunas(){
        jTable2.getColumnModel().getColumn(0).setWidth(10);
        jTable2.getColumnModel().getColumn(1).setWidth(100);
        jTable2.getColumnModel().getColumn(2).setWidth(120);
        jTable2.getColumnModel().getColumn(3).setWidth(40);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        New = new javax.swing.JButton();
        Deletar = new javax.swing.JButton();
        jBListar = new javax.swing.JButton();
        Alterar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        New.setText("New");

        Deletar.setText("Deletar");

        jBListar.setText("Listar");

        Alterar.setText("Alterar");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Nome", "Email", "Cargo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(jTable2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(75, 75, 75)
                        .addComponent(New)
                        .addGap(18, 18, 18)
                        .addComponent(jBListar)
                        .addGap(18, 18, 18)
                        .addComponent(Alterar)
                        .addGap(18, 18, 18)
                        .addComponent(Deletar)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(New)
                    .addComponent(jBListar)
                    .addComponent(Alterar)
                    .addComponent(Deletar))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Alterar;
    private javax.swing.JButton Deletar;
    private javax.swing.JButton New;
    private javax.swing.JButton jBListar;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable2;
    // End of variables declaration//GEN-END:variables
}
