package control;

import Vew.Cadastro;
import Vew.ListarFuncionarios;
import Vew.Menu;
import Vew.Tabela;
import java.util.ArrayList;
import model.Funcionarios;
import model.FuncionarioDAO;

public class Aula01 {

    public static void main(String[] args) {
        
        //FuncionarioDAO banco = new FuncionarioDAO();
        
        //ArrayList<Funcionarios> lista = banco.listarFuncionarios();
        /*
        for(int i=0; i < lista.size();i++){
            System.out.println("ID: "+lista.get(i
            ).getID());
            System.out.println("Nome: "+lista.get(i).getNome());
            System.out.println("Email: "+lista.get(i).getEmail());
           System.out.println("Cargo: "+lista.get(i).getCargo());
        }
        banco.inserirFuncionario(new Funcionarios(0,"Luiz Inacio","inaz@gmail","Futuro Presidente"));        
       //banco.inserirFuncionario(new Funcionarios(0,"Luiz Inacio","inaz@gmail","Futuro Presidente"));
        */
         
        //-------------------------------------------------------
        //Controller c = new Controller(new Menu(), new Cadastro(), new Tabela());
        //c.initController();
        //banco.inserirFuncionario(new Funcionarios(0,"Luiz Inacio","inaz@gmail","Futuro Presidente"));
        
        //-------------------------------------------------------
        
       ListarFuncionarios lista = new ListarFuncionarios();
       Cadastro cadastro = new Cadastro();
       FuncionarioController fc = new FuncionarioController(lista, cadastro);      
       fc.initController();
       lista.setVisible(true); 
       TelaController tc = new TelaController(cadastro, lista);
       fc.initController();
       tc.initController();
       lista.setVisible(true);
    }
}
