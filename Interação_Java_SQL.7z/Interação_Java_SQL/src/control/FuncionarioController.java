
package control;

import Vew.Cadastro;
import model.Funcionarios;
import Vew.ListarFuncionarios;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import model.FuncionarioDAO;
import javax.swing.table.DefaultTableModel;


public class FuncionarioController {
    private ListarFuncionarios lista;
    private FuncionarioDAO dao = new FuncionarioDAO();
    private Cadastro cadastro;
    
    public FuncionarioController(ListarFuncionarios lista, Cadastro cadastro){
        this.lista = lista;
        this.cadastro = cadastro;
    }
    
    public void initController(){
        lista.getjBListar().addActionListener(e -> listarFuncionarios()); 
        lista.getDeletar().addActionListener(e -> deletarFuncionarios()); 
        cadastro.getjBSalvar().addActionListener(e -> salvarFuncionarios());
    }
    private void deletarFuncionarios(){
        JTable tabela = lista.getjTable2();
        int linha = tabela.getSelectedRow();
        System.out.println("LINHA: " + linha);
        if(linha != -1){
            //deleto o funcionário
            int ID = Integer.parseInt(tabela.getValueAt(linha, 0)+"");
            String nome = tabela.getValueAt(linha,1)+"";
            String email = tabela.getValueAt(linha,2)+"";
            String cargo = tabela.getValueAt(linha,3)+"";
            Funcionarios funcionario = new Funcionarios(ID, nome, email, cargo);
            int confirmDialog = JOptionPane.showConfirmDialog(null,"Você deseja mesmo deletar este funcionário?");
            if(confirmDialog == 0){
                dao.deletarFuncionario(funcionario);
                listarFuncionarios();
            }
            
        }else{
            JOptionPane.showMessageDialog(null, "Selecione o funcionário para ser deletado");
        }
    }    
    private void listarFuncionarios(){
        ArrayList<Funcionarios> listarFuncionarios = dao.listarFuncionarios();
        DefaultTableModel mode1 = ((DefaultTableModel) lista.getjTable2().getModel());
        
        for (int i =0; i<listarFuncionarios.size();i++){
            mode1.addRow(new String[] {listarFuncionarios.get(i).getID()+"",
            listarFuncionarios.get(i).getNome(),
            listarFuncionarios.get(i).getEmail(),
            listarFuncionarios.get(i).getCargo(),});
            }
        }
    
    private void salvarFuncionario(){       
        String nome = cadastro.getjTName().getText();
        String email = cadastro.getjTEmail().getText();
        String cargo = cadastro.getjTCargo().getText();
        
        /*
        Funcionarios funcionario = new Funcionarios(nome, email, cargo);
        dao.salvarFuncionarios(funcionario);
        cadastro.
        */
        
    }
    
    }
    

