
package control;

import Vew.Cadastro;
import Vew.Menu;
import model.dao;


public class Controller {
    private Menu menu;
    private Cadastro cadastro;
    private dao dao = new dao();
    
    public Controller(Menu menu, Cadastro cadastro) {
        this.menu = menu;
        this.cadastro = cadastro;
    }
    
    public void initController(){
        menu.setVisible(true);
        menu.getjBCadastro().addActionListener(e->exibirTelaCadastro());
        cadastro.getjBMenu().addActionListener(e->exibirTelaMenu());
        //salvar: renomer ele
        cadastro.getjButton1().addActionListener(e->salvarFuncionario());
    }
    
    private void salvarFuncionario(){
        System.out.println(cadastro.getjTextField1().getText() );
    }
    
    private void exibirTelaMenu(){
        menu.setVisible(true);
        cadastro.setVisible(false);                  
    }
     
    private void exibirTelaCadastro(){
        cadastro.setVisible(true);
        menu.setVisible(false);              
    }
    
    
}
