
package Atividade;


public class Arquivo {
    public void ordenarBolha(int[] v){
        // for utilizado para controlar a quantidade de vezes que o vetor será ordenado.
        for(int i = 0; i < v.length - 1; i++) {
         // for utilizado para ordenar o vetor.
          for(int j = 0; j < v.length - 1 - i; j++) {
          /* Se o valor da posição atual do vetor for maior que o proximo valor,
             então troca os valores de lugar no vetor. */
            if(v[j] > v[j + 1]) {
              int aux = v[j];
              v[j] = v[j + 1];
              v[j + 1] = aux;
            }
          }
        }
    }
   
   public void ordenarSelecao(int[] v){
       int menor, indiceMenor;
       for (int i = 0; i < v.length - 1; i++) {
            // antes de comparar, considera-se menor o valor atual do loop
            menor = v[i];
            indiceMenor = i;

            // compara com os outros valores do vetor
            for (int j = i + 1; j < v.length; j++){
                if (v[j] < menor){
                    menor = v[j];
                    indiceMenor = j;
                }
            }

            // troca os valores menor e maior
            v[indiceMenor] = v[i];
            v[i] = menor;
        }       
   }
   
   public void ordenarShellsort(int[] v){
        int i , j , temp, size = v.length;
	    
	    int incremento = 1;
	    while(incremento < size) {
	        incremento = 3 * incremento + 1;
	    }
	     
	    while (incremento > 1) {
	        incremento /= 3;
	        
	        for(i = incremento; i < size; i++) {
	            temp = v[i];
	            j = i - incremento;
	            while (j >= 0 && temp < v[j]) {
	                v[j + incremento] = v[j];
	                j -= incremento;
	            }
	            v [j + incremento] = temp;
	        }
	    }	    
   }
   
   public void ordenarInsercao(int[] v){
        for (int i = 1; i < v.length; i++) { 		
		int j = i;	
		while (j > 0 && v[j] < v[j-1]) {
			int aux = v[j];
			v[j] = v[j - 1];
			v[j - 1] = aux;
			j -= 1;
		}	
	}	
    }
   
   
}