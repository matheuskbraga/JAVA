
package control;

import Vew.Cadastro;
import Vew.Menu;
import Vew.Tabela;
import model.Funcionarios;
import model.FuncionarioDAO;


public class Controller {
    private Menu menu;
    private Cadastro cadastro;
    private Tabela tabela;
    private FuncionarioDAO dao = new FuncionarioDAO();
    
    public Controller(Menu menu, Cadastro cadastro, Tabela tabela) {
        this.menu = menu;
        this.cadastro = cadastro;
        this.tabela = tabela;
    }
    
    public void initController(){
        menu.setVisible(true);
        menu.getjBCadastro().addActionListener(e->exibirTelaCadastro());
        menu.getjBTabela().addActionListener(e->exibirTabela());
        cadastro.getjBMenu().addActionListener(e->exibirTelaMenu());
        //salvar: renomer ele
        cadastro.getjButton1().addActionListener(e->salvarFuncionario());
        tabela.getjBRetornarMenu().addActionListener(e->exibirTelaMenu());
        tabela.getjButton1().addActionListener(e->exibirDadosTabela());      
    }
    
    private void exibirDadosTabela(){    
        
        tabela.getjTable1().setValueAt(cadastro.getjTName().getText(),0,0);
        tabela.getjTable1().setValueAt(cadastro.getjTEmail().getText(),0,1); 
        tabela.getjTable1().setValueAt(cadastro.getjTCargo().getText(),0,2);      
    }
    
    private void exibirTabela(){
        menu.setVisible(false);
        tabela.setVisible(true);
        cadastro.setVisible(false);
    }
    
    private void salvarFuncionario(){     
        
        dao.inserirFuncionario(new Funcionarios(0, cadastro.getjTName().getText(), 
                cadastro.getjTEmail().getText(),cadastro.getjTCargo().getText()));      
    }
    
    private void exibirTelaMenu(){
        menu.setVisible(true);
        cadastro.setVisible(false); 
        tabela.setVisible(false);
    }
     
    private void exibirTelaCadastro(){
        cadastro.setVisible(true);
        menu.setVisible(false);
        tabela.setVisible(false);
    }
    
}
