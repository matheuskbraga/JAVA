
package control;

import Vew.Cadastro;
import Vew.ListarFuncionarios;


public class TelaController {
    private Cadastro cadastro;
    private ListarFuncionarios lista;
    
    public TelaController(Cadastro cadastro, ListarFuncionarios lista){
        this.cadastro = cadastro;
        this.lista = lista;
    }
    public void initController(){
        lista.getNew().addActionListener(e -> exibirCadastro());
        cadastro.getjBMenu().addActionListener(e -> exibirListagem());
    }
    private void exibirCadastro(){
        cadastro.setVisible(true);
        lista.setVisible(false);
    }
    
    private void exibirListagem(){
        cadastro.setVisible(false);
        lista.setVisible(true);
    }
    
}
