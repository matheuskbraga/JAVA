package model;

import ConnectionFactory.ConnectionFactory;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.sql.*;

public class FuncionarioDAO {
   private Connection con;
    
    public ArrayList<Funcionarios> listarFuncionarios(){
        ArrayList<Funcionarios> listaFuncionarios = new ArrayList<Funcionarios>();
        String read = "select * from Funcionarios;";
        try{
            con = new ConnectionFactory().getConnection();
            PreparedStatement pst = con.prepareStatement(read);
            
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                int id = Integer.parseInt(rs.getString(1));
                String nome = rs.getString(2);
                String email = rs.getString(3);
                String cargo = rs.getString(4);
                
                listaFuncionarios.add(new Funcionarios(id,nome,email,cargo));
            }
            con.close();
            return listaFuncionarios;
            
        }catch(Exception e){
            System.out.println(e);
            return null;
        }
    }
    
    //CREATE - Insere pessoas no banco de dados
    //READ - Recuperar informações de funcionarios
    public void inserirFuncionario(Funcionarios funcionario){
        //Criando a query de inserção
        String insert = "insert into funcionarios (DS_Nome, DS_Email,"
                + " DS_Cargo) values(?, ?, ?)";
        
        //Abrir a conexão
        con = new ConnectionFactory().getConnection();
        try{
            //preparar a query para execução       
            PreparedStatement pst = con.prepareStatement(insert);
            //setando os valores a serem inseridos
            pst.setString(1,funcionario.getNome());
            pst.setString(2,funcionario.getEmail());
            pst.setString(3,funcionario.getCargo());
            //executando a query
            pst.execute();
            //fechar conexão
            con.close();
            pst.close();                      
        }catch(SQLException e){
            System.out.println("ERRO AO INSERIR REGISTRO: " + e);
        }
    }
    //UPDATE - Alterar informações de um funcionário
    
    public void editarFuncionario(Funcionarios funcionario){
        //
        String update = "update funcionario set nome = ?, email = ?, where ID = ?;";
        //Abrindo conexão
        con = new ConnectionFactory().getConnection();
        try {
            //
            PreparedStatement pst = con.prepareStatement(update);
            //
            pst.setString(1, funcionario.getNome());
            pst.setString(2, funcionario.getEmail());
            pst.setString(3, funcionario.getCargo());
            pst.setString(4, funcionario.getID()+"");
            pst.executeUpdate();
            con.close();
            pst.close();
        } catch (SQLException e) {
            System.out.println("ERRO AO ATUALIZAR O CAMPO: " + e);
        }
    }
    
    public void deletarFuncionario(Funcionarios funcionario){
        // query para deletar funcionario
        String delete = "delete from funcionario where ID = ?;";
        //abrir a conexão
        con = new ConnectionFactory().getConnection();
        try{
            //preparar a query para execução       
            PreparedStatement pst = con.prepareStatement(delete);
            // setando o funcionario a ser excluído
            pst.setString(1, funcionario.getID()+"");
            //executando a query
            pst.execute();
            //fechar conexão
            con.close();
            pst.close();                      
        }catch(SQLException e){
            System.out.println("ERRO AO DELETAR FUNCIONÁRIO: " + e);
        }
    }
}
