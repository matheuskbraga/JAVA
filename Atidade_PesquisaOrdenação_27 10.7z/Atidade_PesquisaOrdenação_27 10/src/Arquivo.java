
import java.util.Random;


public class Arquivo {
    public static int[] gerarVetor(int tam){
        int []vetor = new int[tam];
        Random gerador = new Random();
        
        for(int i = 0; i < vetor.length; i++){
            vetor[i] = gerador.nextInt(100000);
        }
        return vetor;
    }
    
    public void ordenarBolha(int[] v){       
        for(int i = 0; i < v.length - 1; i++) {       
          for(int j = 0; j < v.length - 1 - i; j++) {         
            if(v[j] > v[j + 1]) {
              int aux = v[j];
              v[j] = v[j + 1];
              v[j + 1] = aux;
            }
          }
        }
    }
}
