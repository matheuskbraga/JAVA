
package com.mycompany.hash;

import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JOptionPane;
import java.util.Collections;
import java.util.Iterator;

public class Hash4 {

    public static void main(String[] args) {
        HashSet<Aluno> listaComControleDuplicidade = new HashSet<>();

        String nome;
        int matricula;
        Aluno aluno = null;
        while (true) {
            nome = JOptionPane.showInputDialog(null, "Informe um nome: ");
            if (nome.equals("sair")) {
                break;
            }
            try {
                matricula = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe a matrícula: "));

                aluno = new Aluno(matricula, nome);

                if (listaComControleDuplicidade.add(aluno)) {
                System.out.println("INSERIDO COM SUCESSO!");
                System.out.println("Nome: " + aluno.nome);
                System.out.println("Matrícula: " + aluno.matricula);
                System.out.println("---------------------------");
                } else {
                System.out.println("Aluno já existente");
                System.out.println("---------------------------");
                }                
            } catch (Exception e) {
                continue;
            }          
        }

        for (Iterator<Aluno> p = listaComControleDuplicidade.iterator(); p.hasNext();) {
            System.out.println(p.next());
        }
        
        int m = Integer.parseInt(JOptionPane.showInputDialog(null,"Informe matricula de pesquisa: "));
       
        if (listaComControleDuplicidade.contains(new Aluno(m))) {
            System.out.println(aluno.matricula + "  ENCONTRADO!");
        }       
    }
}
