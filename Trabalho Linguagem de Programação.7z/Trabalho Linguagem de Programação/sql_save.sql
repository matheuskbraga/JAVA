#Criando o banco de dados
CREATE database Aula03agenda;

#Usando o banco de dados
USE Aula03agenda;

CREATE table DadosLoginSenha (
	ID int not null auto_increment primary key,
	Nome varchar(50),
    Login varchar(50),
    Senha varchar(30));
    
INSERT INTO DadosLoginSenha (Nome, Login, Senha)
VALUES ('Paulo André M.M','paulo@gmail.com','Programador'); 
    
desc DadosLoginSenha;



