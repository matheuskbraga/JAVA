package Controller;

import Model.DadosLoginsenha;
import Model.DadosLoginsenhaDAO;
import View.CadastroLoginsenha;
import View.ListarLoginsenha;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import javax.crypto.NoSuchPaddingException;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class LoginsenhaController {

    private ListarLoginsenha lista;
    private DadosLoginsenhaDAO dao = new DadosLoginsenhaDAO();
    private CadastroLoginsenha cadastro;

    public LoginsenhaController(ListarLoginsenha lista, CadastroLoginsenha cadastro) {
        this.lista = lista;
        this.cadastro = cadastro;
    }

    public void initController() {
        //listar os logins e senhas
        lista.getjBList().addActionListener(e -> listarDados());
        //Deletar os logins e senhas
        lista.getjBDelete().addActionListener(e -> deletarDados());
        //Inserir os logins e senhas no banco
        cadastro.getjBInsert().addActionListener(e -> inserirLoginsenha());
        //Editar logins e senhas
        lista.getjBUpdate().addActionListener(e -> editarDados());
    }

    //Inserir
    private void inserirLoginsenha() {
        String nome = cadastro.getjTFName().getText();
        String login = cadastro.getjTFLogin().getText();
        String senha = cadastro.getjTFSenha().getText();
        //encapsulando os dados
        DadosLoginsenha dadosLoginsenha = new DadosLoginsenha(nome,login,senha);
        //salvdando no banco
        dao.inserirLogin_senha(dadosLoginsenha);
        //Avisar quer o registro foi salvo
        JOptionPane.showMessageDialog(null, "DADOS SALVOS!");
        //limpar dados
        cadastro.limparCampos();
    }

    //Listar
    private void listarDados(){
        ArrayList<DadosLoginsenha> listaDeDados = dao.listarDadosLoginsenha();
        DefaultTableModel model = ((DefaultTableModel) lista.getjTable1().getModel());
        //Limpar as linhas da tabela
        model.setRowCount(0);
        for (int i = 0; i < listaDeDados.size(); i++) {
            model.addRow(new String[]{listaDeDados.get(i).getId() + "",
                listaDeDados.get(i).getNome(),
                listaDeDados.get(i).getLogin(),
                listaDeDados.get(i).getSenha()});
        }
    }
    
    //Delete
    private void deletarDados() {
        JTable tabela = lista.getjTable1();
        int linha = tabela.getSelectedRow();
        System.out.println("LINHA: " + linha);
        //Verifica se tem algum funcionario selecionado
        if (linha != -1) {
            //Encapsula as informações de um funcionario
            int id = Integer.parseInt(tabela.getValueAt(linha, 0) + "");
            String nome = tabela.getValueAt(linha, 1) + "";
            String login = tabela.getValueAt(linha, 2) + "";
            String senha = tabela.getValueAt(linha, 3) + "";
            DadosLoginsenha dadosLoginsenha = new DadosLoginsenha(id, nome, login, senha);
            //Verificação de deleção
            int showConfirmDialog = JOptionPane.showConfirmDialog(null, "DELETAR DADO: "
                    + dadosLoginsenha.toString());
            if (showConfirmDialog == 0) {
                //deltar o funcionario do banco
                dao.deletarDados(dadosLoginsenha);
                //Atualizar a lista
                listarDados();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Selecione a linha do dado que deseja deletar!");
        }
    }

    //Update
    private void editarDados() {       
        JTable tabela = lista.getjTable1();
        int linha = tabela.getSelectedRow();
        //int campo = tabela.
        System.out.println("linha" + linha);
        if(linha != -1){
            int id = Integer.parseInt(tabela.getValueAt(linha,0)+"");            
            String nome = tabela.getValueAt(linha, 1)+"";
            String login = tabela.getValueAt(linha, 2)+"";
            String senha = tabela.getValueAt(linha, 3)+"";
            DadosLoginsenha dadosLoginsenha = new DadosLoginsenha(id, nome, login, senha);
            int showConfirmDialog = JOptionPane.showConfirmDialog(null, "ALTERAR DADO?");
            if (showConfirmDialog == 0) {
                //editar o dado do banco
                dao.editarDados(dadosLoginsenha);
                //Atualizar a lista
                listarDados();
            }
        } else {
            JOptionPane.showMessageDialog(null, "Selecione o dado que deseje alterar!");
        }        
    }
}
