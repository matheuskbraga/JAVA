
package Controller;

import View.CadastroLoginsenha;
import View.Confirmacao;
import View.ListarLoginsenha;
import View.Menu;
import javax.swing.JOptionPane;

public class TelaController {
    private Confirmacao confirmacao;
    private Menu menu;
    private CadastroLoginsenha cadastro;
    private ListarLoginsenha lista;

    public TelaController(CadastroLoginsenha cadastro, ListarLoginsenha lista, Menu menu, Confirmacao confirmacao){
        this.confirmacao = confirmacao;
        this.cadastro = cadastro;
        this.lista = lista;
        this.menu = menu;
    }
    
    public void initController(){
        //Exibicao inicial do menu
        exibirMenu();                 
        //Botao para logar no banco
        menu.getjEntrar_Menu().addActionListener(e -> analiseLoginSenha());
        //Botao para confirmar e entrar no banco
        confirmacao.getjBConfirm().addActionListener(e -> analiseTelaConfirm());
        //Finalizar no início/menu
        menu.getjBFinish().addActionListener(e -> finalizarProgramMenu());
        //Finalizar na confirmação
        confirmacao.getjBCancel2().addActionListener(e -> exibirMenu());
    }
    
    private void exibirTelaCadastro(){
        cadastro.setVisible(true);
        lista.setVisible(false);
        menu.setVisible(false);
    }
    private void exibirTelaListagem(){
        lista.setVisible(true);
        cadastro.setVisible(false);
        menu.setVisible(false);
        confirmacao.setVisible(false);
    }
    private void exibirMenu(){
        menu.setVisible(true);
        lista.setVisible(false);
        cadastro.setVisible(false);
        confirmacao.setVisible(false);
    }
    private void exibeConfirm(){
        menu.setVisible(false);
        lista.setVisible(false);
        cadastro.setVisible(false);
        confirmacao.setVisible(true);
    }
    private void finalizarProgram(){
        lista.setVisible(false);
    }
    private void finalizarProgramMenu(){
        menu.setVisible(false);      
    }
   
    private void analiseLoginSenha(){       
       if(menu.getjNome_menu().getText().equals("Matheus Braga") && 
               menu.getjSenha_menu().getText().equals("12345")){
           exibeConfirm();        
       } else {
            JOptionPane.showMessageDialog(null,"LOGIN OU SENHA INCORRETOS!");
       }  
    }
    
    private void analiseTelaConfirm(){      
        if(confirmacao.getjText_animal().getText().equals("Cachorro") && 
                   confirmacao.getjText_comida().getText().equals("Xis") && 
                   confirmacao.getjText_profissao().getText().equals("Programador")){             
            //Exibe a tabela
            exibirTelaListagem();
            //Exibe a taela de cadastro
            lista.getjBNew().addActionListener(e -> exibirTelaCadastro());
            //Mudar da tela de cadastro para tela listagem
            cadastro.getjBReturn().addActionListener(e -> exibirTelaListagem());
            //Finalizar programa
            lista.getjBFinal().addActionListener(e -> finalizarProgram());
           } else {
               JOptionPane.showMessageDialog(null,"INFORMAÇÕES ERRADAS!");
           }
    }
}