
package View;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class Menu extends javax.swing.JFrame {

    
    public Menu() {
        initComponents();
    }

    public JTextField getjNome_menu() {
        return jNome_menu;
    }

    public JTextField getjSenha_menu() {
        return jSenha_menu;
    }

    public JButton getjEntrar_Menu() {
        return jEntrar_Menu;
    }

    public JButton getjBFinish() {
        return jBFinish;
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jEntrar_Menu = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jNome_menu = new javax.swing.JTextField();
        jSenha_menu = new javax.swing.JTextField();
        jBFinish = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(190, 106, 1));
        setForeground(new java.awt.Color(51, 204, 255));

        jLabel1.setBackground(new java.awt.Color(255, 0, 0));
        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        jLabel1.setText("Vault de senhas");

        jEntrar_Menu.setBackground(new java.awt.Color(255, 255, 255));
        jEntrar_Menu.setFont(new java.awt.Font("Algerian", 0, 12)); // NOI18N
        jEntrar_Menu.setForeground(new java.awt.Color(0, 0, 0));
        jEntrar_Menu.setText("ENTRAR");
        jEntrar_Menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEntrar_MenuActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel2.setText("Nome:");

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel3.setText("Senha:");

        jNome_menu.setBackground(new java.awt.Color(255, 255, 255));
        jNome_menu.setForeground(new java.awt.Color(0, 0, 0));
        jNome_menu.setText("Matheus Braga");
        jNome_menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jNome_menuActionPerformed(evt);
            }
        });

        jSenha_menu.setBackground(new java.awt.Color(255, 255, 255));
        jSenha_menu.setFont(new java.awt.Font("Wingdings 3", 0, 12)); // NOI18N
        jSenha_menu.setForeground(new java.awt.Color(0, 0, 0));
        jSenha_menu.setText("12345");
        jSenha_menu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSenha_menuActionPerformed(evt);
            }
        });

        jBFinish.setBackground(new java.awt.Color(255, 255, 255));
        jBFinish.setFont(new java.awt.Font("Algerian", 0, 12)); // NOI18N
        jBFinish.setForeground(new java.awt.Color(0, 0, 0));
        jBFinish.setText("CANCELAR");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(192, 192, 192)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jEntrar_Menu)
                                .addGap(18, 18, 18)
                                .addComponent(jBFinish))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jNome_menu, javax.swing.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                                .addComponent(jSenha_menu)))))
                .addContainerGap(175, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(116, 116, 116)
                .addComponent(jLabel1)
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jNome_menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jSenha_menu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jEntrar_Menu)
                    .addComponent(jBFinish))
                .addContainerGap(164, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jSenha_menuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSenha_menuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jSenha_menuActionPerformed

    private void jEntrar_MenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEntrar_MenuActionPerformed
     
    }//GEN-LAST:event_jEntrar_MenuActionPerformed

    private void jNome_menuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jNome_menuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jNome_menuActionPerformed

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBFinish;
    private javax.swing.JButton jEntrar_Menu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField jNome_menu;
    private javax.swing.JTextField jSenha_menu;
    // End of variables declaration//GEN-END:variables
}
