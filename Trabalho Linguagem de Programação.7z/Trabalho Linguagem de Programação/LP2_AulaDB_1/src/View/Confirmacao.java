
package View;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JTextField;


public class Confirmacao extends javax.swing.JFrame {

    
    public Confirmacao() {
        initComponents();
    }

    public JTextField getjText_animal() {
        return jText_animal;
    }

    public JTextField getjText_comida() {
        return jText_comida;
    }

    public JTextField getjText_profissao() {
        return jText_profissao;
    }

    public JButton getjBConfirm() {
        return jBConfirm;
    }

    public JButton getjBCancel2() {
        return jBCancel2;
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jText_animal = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jText_comida = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jText_profissao = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jBConfirm = new javax.swing.JButton();
        jBCancel2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel1.setText("Animal favorito:");

        jText_animal.setBackground(new java.awt.Color(255, 255, 255));
        jText_animal.setFont(new java.awt.Font("Wingdings 3", 0, 12)); // NOI18N
        jText_animal.setText("Cachorro");

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel2.setText("Comida favorita:");

        jText_comida.setBackground(new java.awt.Color(255, 255, 255));
        jText_comida.setFont(new java.awt.Font("Wingdings 3", 0, 12)); // NOI18N
        jText_comida.setText("Xis");

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 12)); // NOI18N
        jLabel3.setText("Profissão:");

        jText_profissao.setBackground(new java.awt.Color(255, 255, 255));
        jText_profissao.setFont(new java.awt.Font("Wingdings 3", 0, 12)); // NOI18N
        jText_profissao.setText("Programador");

        jLabel4.setFont(new java.awt.Font("Arial Black", 0, 36)); // NOI18N
        jLabel4.setText("CONFIRMAÇÃO");

        jBConfirm.setBackground(new java.awt.Color(255, 255, 255));
        jBConfirm.setFont(new java.awt.Font("Algerian", 0, 12)); // NOI18N
        jBConfirm.setForeground(new java.awt.Color(0, 0, 0));
        jBConfirm.setText("CONFIRMAR");

        jBCancel2.setBackground(new java.awt.Color(255, 255, 255));
        jBCancel2.setFont(new java.awt.Font("Algerian", 0, 12)); // NOI18N
        jBCancel2.setForeground(new java.awt.Color(0, 0, 0));
        jBCancel2.setText("CANCELAR");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(78, Short.MAX_VALUE)
                .addComponent(jBConfirm)
                .addGap(18, 18, 18)
                .addComponent(jBCancel2)
                .addGap(91, 91, 91))
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jText_animal, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jText_comida, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jText_profissao, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(41, Short.MAX_VALUE)
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jText_animal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jText_comida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jText_profissao, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jBConfirm)
                    .addComponent(jBCancel2))
                .addGap(42, 42, 42))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBCancel2;
    private javax.swing.JButton jBConfirm;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField jText_animal;
    private javax.swing.JTextField jText_comida;
    private javax.swing.JTextField jText_profissao;
    // End of variables declaration//GEN-END:variables
}
