
package View;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JTable;


public class ListarLoginsenha extends javax.swing.JFrame {

    
    public ListarLoginsenha() {
        initComponents();
        alterarColunas();
    }
    
     public JButton getjBDelete() {
        return jBDelete;
    }

    public JButton getjBList() {
        return jBList;
    }

    public JButton getjBUpdate() {
        return jBUpdate;
    }

    public JTable getjTable1() {
        return jTable1;
    }

    public JButton getjBNew() {
        return jBNew;
    }

    public JButton getjBFinal() {
        return jBFinal;
    }
     
    public void alterarColunas(){
        jTable1.getColumnModel().getColumn(0).setPreferredWidth(10);
        jTable1.getColumnModel().getColumn(1).setPreferredWidth(100);
        jTable1.getColumnModel().getColumn(2).setPreferredWidth(120);
        jTable1.getColumnModel().getColumn(3).setPreferredWidth(40);
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jBNew = new javax.swing.JButton();
        jBUpdate = new javax.swing.JButton();
        jBList = new javax.swing.JButton();
        jBDelete = new javax.swing.JButton();
        jBFinal = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(143, 65, 0));

        jTable1.setBackground(new java.awt.Color(255, 255, 255));
        jTable1.setFont(new java.awt.Font("Leelawadee UI", 0, 12)); // NOI18N
        jTable1.setForeground(new java.awt.Color(0, 0, 0));
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Num de Registro", "Plataforma", "Login", "Senha"
            }
        ));
        jTable1.setGridColor(new java.awt.Color(0, 0, 0));
        jTable1.setSelectionForeground(new java.awt.Color(0, 0, 255));
        jScrollPane1.setViewportView(jTable1);

        jBNew.setBackground(new java.awt.Color(255, 255, 255));
        jBNew.setFont(new java.awt.Font("Algerian", 0, 18)); // NOI18N
        jBNew.setForeground(new java.awt.Color(0, 0, 0));
        jBNew.setText("NEW");

        jBUpdate.setBackground(new java.awt.Color(255, 255, 255));
        jBUpdate.setFont(new java.awt.Font("Algerian", 0, 18)); // NOI18N
        jBUpdate.setForeground(new java.awt.Color(0, 0, 0));
        jBUpdate.setText("Update");

        jBList.setBackground(new java.awt.Color(255, 255, 255));
        jBList.setFont(new java.awt.Font("Algerian", 0, 18)); // NOI18N
        jBList.setForeground(new java.awt.Color(0, 0, 0));
        jBList.setText("List");

        jBDelete.setBackground(new java.awt.Color(255, 255, 255));
        jBDelete.setFont(new java.awt.Font("Algerian", 0, 18)); // NOI18N
        jBDelete.setForeground(new java.awt.Color(0, 0, 0));
        jBDelete.setText("Delete");

        jBFinal.setBackground(new java.awt.Color(255, 255, 255));
        jBFinal.setFont(new java.awt.Font("Algerian", 0, 18)); // NOI18N
        jBFinal.setForeground(new java.awt.Color(0, 0, 0));
        jBFinal.setText("FINALIZAR");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(339, 339, 339)
                .addComponent(jBNew)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBUpdate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBList)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jBDelete)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 207, Short.MAX_VALUE)
                .addComponent(jBFinal)
                .addContainerGap())
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jBNew)
                    .addComponent(jBUpdate)
                    .addComponent(jBList)
                    .addComponent(jBDelete)
                    .addComponent(jBFinal))
                .addGap(0, 10, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBDelete;
    private javax.swing.JButton jBFinal;
    private javax.swing.JButton jBList;
    private javax.swing.JButton jBNew;
    private javax.swing.JButton jBUpdate;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
