package App;

import Controller.LoginsenhaController;
import Controller.TelaController;
import Model.DadosLoginsenhaDAO;
import Model.DadosLoginsenha;
import View.ListarLoginsenha;
import View.CadastroLoginsenha;
import View.ListarLoginsenha;
import View.Menu;
import View.Confirmacao;
import java.util.ArrayList;
import javax.swing.JFrame;

public class App {
    
    public static void main(String[] args) {        
        Menu menu = new Menu();  
        Confirmacao confirmacao = new Confirmacao();
        ListarLoginsenha lista = new ListarLoginsenha();
        CadastroLoginsenha cadastro = new CadastroLoginsenha();
        LoginsenhaController lc = new LoginsenhaController(lista, cadastro);               
        TelaController tc = new TelaController(cadastro, lista, menu, confirmacao);
        lc.initController();
        tc.initController();
    }
}
