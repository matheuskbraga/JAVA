package Model;

import ConnectionFactory.ConnectionFactory;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.ArrayList;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

public class DadosLoginsenhaDAO {
    private Connection con;
    
    //CREATE - Insere login e senha no banco de dados
    public void inserirLogin_senha(DadosLoginsenha dadosLogin_senha){
        //Criando aquery de inserção
        String insert = "Insert into DadosLoginSenha(nome,login,senha) "
                + "values (?, ?, ?);";
        //Abrir a conexão
        con = new ConnectionFactory().getConnection();
        try {
            //Preparar a query para execução
            PreparedStatement pst = con.prepareStatement(insert);
            //Setando o valores a serem inseridos
            pst.setString(1, dadosLogin_senha.getNome());
            pst.setString(2, dadosLogin_senha.getLogin());
            pst.setString(3, dadosLogin_senha.getSenha());
            //Executando a query
            pst.execute();
            //Fechando a conexão
            con.close();
            pst.close();
        } catch (SQLException e) {
            System.out.println("ERRO AO INSERIR REGISTRO: " + e);
        }     
    }
    
    //READ - Recupar informações de Logins e Senhas
    public ArrayList<DadosLoginsenha> listarDadosLoginsenha(){      
        //criar lista de Logins e senhas
        ArrayList<DadosLoginsenha> listaDadosLoginsenha = new ArrayList();
        //declarar a query utilizada para retonar dados de logins e senhas
        String read = "select * from DadosLoginSenha;";
        try {
            //abrir a conexão
            con = new ConnectionFactory().getConnection();
            //preparar a query para execução no banco de dados
            PreparedStatement pst = con.prepareStatement(read);
            //executar a query e armazena em um RS
            ResultSet rs = pst.executeQuery();
            //passando os valores contidos no RS para a lista de Loginsenhas          
            while(rs.next()){
                int id =  Integer.parseInt(rs.getString(1));                            
                String nome = rs.getString(2);
                String login = rs.getString(3);              
                String senha = rs.getString(4);
               
                //adicionar um novo dado a Lista
                listaDadosLoginsenha.add(new DadosLoginsenha(id, nome, login, senha));
            }
            con.close();
            return listaDadosLoginsenha;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        } 
    }
    
    //UPDATE - Alterar informações de um dado
    public void editarDados(DadosLoginsenha dadosEdit){
        //declarar a query
        String update = "update DadosLoginSenha set nome = ?, login = ?, senha = ?"
                + " where ID = ?;";
        //Abrindo conexão 
        con = new ConnectionFactory().getConnection();
        try {
            //preparando a query
            PreparedStatement pst = con.prepareStatement(update);
            //setar os valor do update
            pst.setString(1, dadosEdit.getNome()+"");
            pst.setString(2, dadosEdit.getLogin()+"");
            pst.setString(3, dadosEdit.getSenha()+"");
            pst.setString(4, dadosEdit.getId()+"");
            //executa a query
            pst.executeUpdate();
            //fecha conexão
            con.close();
            pst.close();
        } catch (SQLException e) {
            System.out.println("ERRO AO EDITAR O BANCO:" + e);
        }
    }
    
    
    //DELETE - Remover um registro do banco
    public void deletarDados(DadosLoginsenha dados){
        //query para deletar dado
        String delete = "delete from DadosLoginSenha where id = ?;";
        //abriri a conexão
        con = new ConnectionFactory().getConnection();
        try {
            //preparando a query
            PreparedStatement pst = con.prepareStatement(delete);
            //setando o dado a ser excluido
            pst.setString(1, dados.getId()+"");
            //executando a query
            pst.execute();
            //fechando a conexão
            con.close();
            pst.close();
        } catch (SQLException e) {
            System.out.println("ERRO AO DELETAR DADO:" + e);
        }  
    }
}
